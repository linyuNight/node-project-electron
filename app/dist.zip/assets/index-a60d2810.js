import{_ as t}from"./index-0db333d4.js";const c={};function e(r,n){return" chatgpt "}const o=t(c,[["render",e]]);export{o as default};
