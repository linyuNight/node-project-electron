import{_ as e,b as _,c as l}from"./index-0db333d4.js";const o={},s={class:"hello"};function c(t,n){return _(),l("div",s,"hello")}const r=e(o,[["render",c]]);export{r as default};
